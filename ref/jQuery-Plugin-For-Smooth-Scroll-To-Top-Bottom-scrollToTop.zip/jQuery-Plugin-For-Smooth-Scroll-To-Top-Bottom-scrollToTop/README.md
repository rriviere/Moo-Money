jquery.scrollToTop
==================
Plugin that add scroll to top (bottom) button on your page.
